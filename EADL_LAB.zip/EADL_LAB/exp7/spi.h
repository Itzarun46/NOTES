#ifndef SPI_H
#define SPI_H

#include <stdint.h>

// Function to initialize SPI
int spi_init(const char *device, uint32_t speed);

// Function to configure SPI mode
int spi_configure(int fd, uint32_t mode);

// Function to perform SPI transfer
int spi_transfer(int fd, uint8_t *tx_buffer, uint8_t *rx_buffer, uint32_t len);

// Function to close SPI device
void spi_close(int fd);

#endif // SPI_H

