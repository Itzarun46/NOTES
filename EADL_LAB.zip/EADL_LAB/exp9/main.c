#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include "pwm.h"

// ./pwm_example 100 1
//                period duty_cycle
int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <period> <duty_cycle>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int period = atoi(argv[1]);
    int duty_cycle_value = atoi(argv[2]);

    pwm_export();
    pwm_set_period(argv[1]);
    pwm_enable();

    while (1) {
        pwm_set_duty_cycle(duty_cycle_value);
        printf("PWM duty cycle: %d\n", duty_cycle_value);
        duty_cycle_value++;
        usleep(100000);
        if (duty_cycle_value >= period) {
            duty_cycle_value = 0;
        }
    }

    pwm_disable();
    return EXIT_SUCCESS;
}

