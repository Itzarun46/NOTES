#include "pwm.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

char export_path[] = "/sys/class/pwm/pwmchip0/export";
char pwm_periods[] = "/sys/class/pwm/pwmchip0/pwm1/period";
char pwm_enable_path[] = "/sys/class/pwm/pwmchip0/pwm1/enable";
char duty_cycle_path[] = "/sys/class/pwm/pwmchip0/pwm1/duty_cycle";

void pwm_export() {
    int fd = open(export_path, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open export path");
        exit(EXIT_FAILURE);
    }
    write(fd, "1", 2);
    close(fd);
}

void pwm_set_period(const char *period) {
    int fd = open(pwm_periods, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open period path");
        exit(EXIT_FAILURE);
    }
    write(fd, period, strlen(period) + 1);
    close(fd);
}

void pwm_enable() {
    int fd = open(pwm_enable_path, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open enable path");
        exit(EXIT_FAILURE);
    }
    write(fd, "1", 2);
    close(fd);
}

void pwm_disable() {
    int fd = open(pwm_enable_path, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open enable path");
        exit(EXIT_FAILURE);
    }
    write(fd, "0", 2);
    close(fd);
}

void pwm_set_duty_cycle(int duty_cycle) {
    int fd = open(duty_cycle_path, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open duty cycle path");
        exit(EXIT_FAILURE);
    }

    char value_str[16];
    sprintf(value_str, "%d", duty_cycle);
    write(fd, value_str, strlen(value_str) + 1);
    close(fd);
}

