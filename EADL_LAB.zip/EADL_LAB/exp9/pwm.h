#ifndef PWM_H
#define PWM_H

void pwm_export();
void pwm_set_period(const char *period);
void pwm_enable();
void pwm_disable();
void pwm_set_duty_cycle(int duty_cycle);

#endif // PWM_H

