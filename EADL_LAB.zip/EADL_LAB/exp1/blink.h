int blink();

